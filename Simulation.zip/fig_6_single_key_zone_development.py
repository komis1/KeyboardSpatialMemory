###############################################################
# Trials of typing a single key by virtual participant. 
# Plots development of zone for a particular key, given as a
# command line argument.
# Constant or logistic learning modes are definable after the 
# executor object declaration
###############################################################

import datetime
import sys
import random
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle 
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score
import sympy as sp
from scipy.stats import entropy

from Decoder import *
from Finger import *
from LanguageModel import *
from TouchModel import *
from Keyboard import *
from metrics import *
from read_corpus import *
from visualiser import *
from Eye import *
from Executor2 import *
from SpatialMemory import *


mykeyboard = Keyboard('keyboards/opti.xml', 'languagemodel.json', 'touchmodel.json', [1400,1000],[0,0], usedecoder=False)

f=open('virtual_participants/popts_all.json')
participants = sorted(list(json.load(f).keys()))
selected_participant = random.choice(participants)

myfinger=Finger('virtual_participants/popts_all.json', str(selected_participant))
eye = Eye()
eye.position = [mykeyboard.xdim/2, mykeyboard.ydim/2]

#smlayouts  = [[2,1], [2,2], [3,1], [3,2], [3,3], [3,4], [4,4],[5,4]]
#smlayouts  = [[2,1], [2,2], [3,3], [3,4], [4,4],[5,4]]
smlayouts=[[3,3]]
fnlimits = []
it90pcts = []
goodlearnpoint = 0.9


figw=10
figh=round(mykeyboard.ydim/mykeyboard.xdim*figw,1)

fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(figw,figh))
axes=[axes]
for layout in smlayouts:
    sm = SpatialMemory(mykeyboard,region_columns=layout[0],region_rows=layout[1], learningRate=0.003, adjustment='dynamic')
    executor = Executor2(myfinger, eye, mykeyboard, sm, expert_factor=0.1)
    
    #change this to constant or logistic
    executor.memoryUpdateMethod = "constant"
    
    phrase = sys.argv[1]
    
    gazes = []
    times = []
    iters = 1500
    print("left, bottom, right, top")

    #plot the kb
    rect = Rectangle((0,-mykeyboard.ydim), mykeyboard.xdim,mykeyboard.ydim,
                             linewidth=1,edgecolor='black',facecolor='lightgrey')
    axes[0].add_patch(rect)

    #plot the keyboard
    for i in mykeyboard.keylist:
        axes[0].plot(mykeyboard.keylist[i]['center'][0], -mykeyboard.keylist[i]['center'][1], marker='.', color='whitesmoke')
        axes[0].text(mykeyboard.keylist[i]['center'][0], -mykeyboard.keylist[i]['center'][1], mykeyboard.keylist[i]['label'],
                horizontalalignment='center',
                verticalalignment='center',fontsize=5*2, color='grey')
        rect = Rectangle((mykeyboard.keylist[i]['bbox']['left'],-mykeyboard.keylist[i]['bbox']['bottom']),
                         mykeyboard.keylist[i]['xlen'],-mykeyboard.keylist[i]['ylen'],
                         linewidth=1,edgecolor='grey',facecolor='whitesmoke')
        axes[0].add_patch(rect)

    #plot zones
    for i in range(1,layout[0]+1):
        #print('vline at x=',i*int(self.xdim)/zones[0])
        axes[0].vlines(x = i*int(mykeyboard.xdim)/layout[0],
                  ymin=0,
                  ymax=-mykeyboard.ydim,
                  color = 'black', linestyle='solid', label = 'axvline - full height', alpha=1)

    for j in range (1,layout[1]):
        #print('hline at y=',j*int(self.ydim)/zones[1])
        axes[0].hlines(y = -j*int(mykeyboard.ydim)/layout[1], 
                  xmin=0,
                  xmax=mykeyboard.xdim,
                  color = 'black', linestyle='solid', label = 'axvline - full height', alpha=1)

    for i in range(iters):
        #reset state
        mykeyboard.outputbuffer=[]
        mykeyboard.current_word=[]
        mykeyboard.taps=[]
        eye.position = [mykeyboard.xdim/2, mykeyboard.ydim/2]
        executor.eye_positions=[]
        taps = executor.typeSentenceWithCorrection2(phrase, speed=1, noticeprob=1, slides='on', completions=False)
        times.append(taps['time']*60)
        gazes.append(len(executor.eye_positions)/len(phrase))
        #print (sm.spatialMap['probabilities']['a']['home_zone']['bbox'])

    
    #plot
    #left, bottom, right, top
        if i%150==0:
            print (sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'])
          
            axes[0].add_patch( Rectangle(
                                (sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][0], #x
                                -sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][3]), #y of lower left
                              sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][2]-sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][0], #w
                              sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][3]-sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][1], #h
                                facecolor=('#27b0f51a'), edgecolor=(0,0,0.2,1)
                             )
                             )
            #rgba(39, 176, 245, 0.2)

    axes[0].add_patch( Rectangle(
        (sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][0], #x
         -sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][3]), #y of lower left
            sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][2]-sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][0], #w
            sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][3]-sm.spatialMap['probabilities'][phrase]['home_zone']['bbox'][1], #h
            alpha=0.6, edgecolor='black', facecolor='orange')
                )
axes[0].set_xlim(0,mykeyboard.xdim+100)
axes[0].set_ylim(-mykeyboard.ydim-100,0)
print(mykeyboard.keylist[phrase]['bbox'])
#fig.suptitle(phrase)
plt.savefig('imgs/s2-simulations/zone_'+phrase+'.png')

plt.show()
print ("total: "+str(sum(times)//60)+"h"+str(round(sum(times)%60,0))+"m")
#print(json.dumps(executor.spatialMemory.spatialMap, indent=4))
#print(json.dumps(taps, indent=4))

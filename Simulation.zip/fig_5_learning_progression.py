###############################################################
# Trials of typing an English Pangram using a single 
# virtual participant. 
# Plots Saccades per Target and time taken to complete trials.
# Attempts to fit an exponential function to the data.
###############################################################

import datetime
import random
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score
import sympy as sp
from scipy.stats import entropy
import json

from Decoder import *
from Finger import *
from LanguageModel import *
from TouchModel import *
from Keyboard import *
from metrics import *
from read_corpus import *
from visualiser import *
from Eye import *
from Executor2 import *
from SpatialMemory import *


#decay function to fit to the data
def func(x, a, b, c):
    return a * np.exp(-b * x) + c


types = ["logistic", "constant"]

f=open('virtual_participants/popts_all.json')
participants = sorted(list(json.load(f).keys()))
selected_participant = random.choice(participants)

for type in types:

    #reset everything
    mykeyboard = Keyboard('keyboards/qwerty.xml', 'languagemodel.json', 'touchmodel.json', [1400,1000],[0,0], usedecoder=False)
    myfinger=Finger('virtual_participants/popts_all.json', str(selected_participant))
    eye = Eye()
    eye.position = [mykeyboard.xdim/2, mykeyboard.ydim/2]
    smlayouts  = [[2,1], [2,2], [3,1], [3,2], [3,3], [3,4], [4,4],[5,4]]
    fnlimits = []
    
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(10, 5))
    
    for layout in smlayouts:
        sm = SpatialMemory(mykeyboard,region_columns=layout[0],region_rows=layout[1], learningRate=0.003, adjustment='dynamic')
        executor = Executor2(myfinger, eye, mykeyboard, sm, expert_factor=0.1)
        executor.memoryUpdateMethod = type
        
        phrase = "the quick brown fox jumps over the lazy dog"
        keys=list(set(phrase))
        
        gazes = []
        times = []
        iters = 100
        for i in range(iters):
            #reset state
            mykeyboard.outputbuffer=[]
            mykeyboard.current_word=[]
            mykeyboard.taps=[]
            eye.position = [mykeyboard.xdim/2, mykeyboard.ydim/2]
            executor.eye_positions=[]
            taps = executor.typeSentenceWithCorrection2(phrase, speed=1, noticeprob=1, slides='on', completions=False)
            times.append(taps['time']*60)
            gazes.append(len(executor.eye_positions)/len(phrase))
        
        #fit the function
        popt, pcov = curve_fit(func, range(iters), gazes, maxfev=1000)
        y_pred = func(range(iters), *popt)
        r2=round(r2_score(gazes, y_pred),3)
        
        #find the function limit
        x = sp.symbols('x')
        f = popt[0]*sp.exp(-popt[1]*x)+popt[2]
        limit_result = round(float(sp.limit(f, x, sp.oo, dir='+')),3)
        
        fnlimits.append(limit_result)
    
        print(layout,limit_result)
        
        #plot
        axes[0].plot(
                    range(iters), 
                    y_pred, '--',
                    label=str(layout[0])+'x'+str(layout[1])+ ', $R^2$='+str(r2), #' - fit: a=%5.3f, b=%5.3f, c=%5.3f' % tuple(popt), 
                    alpha=0.7
                )
        axes[0].set_title('SPC') 
        axes[0].set_ylabel('Avg. SPC')
        #axes.plot(gazes, alpha=0.4)
        axes[0].set_xlabel('Trials')
        axes[0].set_ylim(0,12)
        axes[0].legend()
    
        m, s = divmod(sum(times), 60)
        h, m = divmod(m, 60)
        m=int(round(m,0))
        h=int(round(h,0))
        s=round(s,3)
        
        #fit the function to times
        #popt, pcov = curve_fit(func, range(iters), times, maxfev=1000)
        #y_pred = func(range(iters), *popt)
        #r2=round(r2_score(gazes, y_pred),3)
        #print(popt)
    
        axes[1].set_title('Time') 
        axes[1].plot(range(iters), times, label="total: "+str(h)+":"+str(m)+":"+str(s), alpha=0.2)
        axes[1].set_ylabel('Time (s)')
        axes[1].set_xlabel('Trials')
        axes[1].set_ylim(0,3*60)
        axes[1].legend()
        
    fig.suptitle("Saccades per Target (SPT) - "+type+" rate of change LV")
    plt.savefig('imgs/s2-simulations/test-'+type+'_full.png')
    
    #plt.show()
    print (fnlimits)
    

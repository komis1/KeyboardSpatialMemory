###############################################################
# Trials of typing an English Pangram using a single 
# virtual participant. 
# Plots the final developed visual zones for all keys.
# Constant or logistic learning modes are definable after the 
# executor object declaration
###############################################################

import datetime
import json
import random
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score
import sympy as sp
from scipy.stats import entropy

from Decoder import *
from Finger import *
from LanguageModel import *
from TouchModel import *
from Keyboard import *
from metrics import *
from read_corpus import *
from visualiser import *
from Eye import *
from Executor2 import *
from SpatialMemory import *


mykeyboard = Keyboard('keyboards/opti.xml', 'languagemodel.json', 'touchmodel.json', [1400,1000],[0,0], usedecoder=False)

f=open('virtual_participants/popts_all.json')
participants = sorted(list(json.load(f).keys()))
selected_participant = random.choice(participants)
myfinger=Finger('virtual_participants/popts_all.json', str(selected_participant))
eye = Eye()
eye.position = [mykeyboard.xdim/2, mykeyboard.ydim/2]


figw=10
figh=round(mykeyboard.ydim/mykeyboard.xdim*figw,1)
fig, axes = plt.subplots(nrows=1, ncols=1, figsize=(figw,figh))
axes=[axes]
#smlayouts  = [[2,1], [2,2], [3,3], [3,4], [4,4],[5,4]]
smlayouts  = [[2,2]]

for layout in smlayouts:

    #plot the kb
    rect = Rectangle((0,-mykeyboard.ydim), mykeyboard.xdim,mykeyboard.ydim,
                             linewidth=1,edgecolor='black',facecolor='lightgrey')
    axes[0].add_patch(rect)

    #plot the keyboard
    for i in mykeyboard.keylist:
        axes[0].plot(mykeyboard.keylist[i]['center'][0], -mykeyboard.keylist[i]['center'][1], marker='.', color='whitesmoke')
        axes[0].text(mykeyboard.keylist[i]['center'][0], -mykeyboard.keylist[i]['center'][1], mykeyboard.keylist[i]['label'],
                horizontalalignment='center',
                verticalalignment='center',fontsize=5*2, color='grey')
        rect = Rectangle((mykeyboard.keylist[i]['bbox']['left'],-mykeyboard.keylist[i]['bbox']['bottom']),
                         mykeyboard.keylist[i]['xlen'],-mykeyboard.keylist[i]['ylen'],
                         linewidth=1,edgecolor='grey',facecolor='whitesmoke')
        axes[0].add_patch(rect)

    #plot zones
    for i in range(1,layout[0]+1):
        #print('vline at x=',i*int(self.xdim)/zones[0])
        axes[0].vlines(x = i*int(mykeyboard.xdim)/layout[0],
                  ymin=0,
                  ymax=-mykeyboard.ydim,
                  color = 'black', linestyle='solid', label = 'axvline - full height', alpha=1)

    for j in range (1,layout[1]):
        #print('hline at y=',j*int(self.ydim)/zones[1])
        axes[0].hlines(y = -j*int(mykeyboard.ydim)/layout[1], 
                  xmin=0,
                  xmax=mykeyboard.xdim,
                  color = 'black', linestyle='solid', label = 'axvline - full height', alpha=1)
    
    sm = SpatialMemory(mykeyboard,region_columns=layout[0],region_rows=layout[1], learningRate=0.003, adjustment='dynamic')
    executor = Executor2(myfinger, eye, mykeyboard, sm, expert_factor=0.1)
    
    #change this to constant or logistic
    executor.memoryUpdateMethod = "constant"
    
    phrase = "the quick brown fox jumps over the lazy dog"
    keys=list(set(phrase))
    
    iters = 500
    for i in range(iters):
        #reset state
        mykeyboard.outputbuffer=[]
        mykeyboard.current_word=[]
        mykeyboard.taps=[]
        eye.position = [mykeyboard.xdim/2, mykeyboard.ydim/2]
        executor.eye_positions=[]
        taps = executor.typeSentenceWithCorrection2(phrase, speed=1, noticeprob=1, slides='on', completions=False)

   # self.spatialMap['probabilities'][key]['home_zone']['bbox']
    for k in sm.spatialMap['probabilities']:
        if 'home_zone' in sm.spatialMap['probabilities'][k]:
            #plot the final zone
            axes[0].add_patch( Rectangle(
                (sm.spatialMap['probabilities'][k]['home_zone']['bbox'][0], #x
                 -sm.spatialMap['probabilities'][k]['home_zone']['bbox'][3]), #y of lower left
                    sm.spatialMap['probabilities'][k]['home_zone']['bbox'][2]-sm.spatialMap['probabilities'][k]['home_zone']['bbox'][0], #w
                    sm.spatialMap['probabilities'][k]['home_zone']['bbox'][3]-sm.spatialMap['probabilities'][k]['home_zone']['bbox'][1], #h
                    alpha=0.2, edgecolor='black', facecolor='orange')
                        )
    fig.suptitle(str(layout[0])+"x"+str(layout[1]))
    plt.savefig('imgs/s2-zones/'+str(layout[0])+"x"+str(layout[1])+'.png')
    plt.show()


from Keyboard import *
from rtree import index
import json

class SpatialMemory:

#spatial map structure

    #{'probabilities'
    
    def __init__(self,kb, region_columns, region_rows, learningRate=0.003, adjustment='none'):
        #load keyboard
        #for each key, create a map with probabilities
        #"k":{"q1":0.25,..}
        self.spatialMap = {}
        self.spatialMap['regions']={}
        self.spatialMap['probabilities']={}
        self.idx = index.Index()
        self.learningRate = learningRate
        self.nregions = region_columns*region_rows
        self.kb = kb
        self.adjustment = adjustment
        
        #create equal prob map
        for key in self.kb.keylist:
            #print(key)
            self.spatialMap['probabilities'][key]={}
            self.spatialMap['probabilities'][key]['regions']={}
            for i in range(self.nregions):
                self.spatialMap['probabilities'][key]['regions']["q"+str(i)]=1/self.nregions
                self.spatialMap['probabilities'][key]['visitations']=0
                

        #print (self.spatialMap)

        #create spatial index (r-tree) to find what region each key belongs to.
        #this is the mind's spatial model of the keyboard
        counter=0
        #print("left, bottom, right, top")
        for i in range(region_rows):
            for j in range(region_columns):
                #insert in master rtree
                #left, bottom, right, top
                
                #print (
                #                            "q"+str(counter),":",
                #                            j*kb.xdim/region_columns, #left
                #                            i*kb.ydim/region_rows,  #bottom
                #                            (j+1)*kb.xdim/region_columns-1, #right
                #                            (i+1)*kb.ydim/region_rows-1 #top
                #                            
                #                        )
                
                self.idx.insert(counter, (
                                            j*kb.xdim/region_columns, #left
                                            i*kb.ydim/region_rows,  #bottom
                                            (j+1)*kb.xdim/region_columns-1, #right
                                            (i+1)*kb.ydim/region_rows-1 #top
                                         ),
                                "q"+str(counter))

                #bbox coords are left, bottom, right, top
                self.spatialMap['regions']["q"+str(counter)]=[
                                                                j*kb.xdim/region_columns, #left
                                                                i*kb.ydim/region_rows, #bottom
                                                                (j+1)*kb.xdim/region_columns-1, #right
                                                                (i+1)*kb.ydim/region_rows-1 #top
                                                             ]
                
                counter+=1
                

        #print(self.idx)

    def getRegion(self, x, y):
        return list(self.idx.intersection((x,y,x,y), objects='raw'))[0]

    def getRegionBbox(self, x, y):
        return list(self.idx.intersection((x,y,x,y), objects=True))[0].bbox

    def updateSpatialMap(self, key, key_coords, method):
        #region to update by quantum for given key
        region = self.getRegion(key_coords[0], key_coords[1])
        #print (method)
        #set region as home zone if needed
        if 'home_zone' not in self.spatialMap['probabilities'][key]:
            self.spatialMap['probabilities'][key]['home_zone']={}
            self.spatialMap['probabilities'][key]['home_zone']['name']=region
            self.spatialMap['probabilities'][key]['home_zone']['bbox']=self.getRegionBbox(key_coords[0],key_coords[1])
            #print(key,self.spatialMap['probabilities'][key]['home_zone']['bbox'])
        #print(key)
        
        quantum=0
        # Adjust the zone probabilities
        if method=="constant":
            #simple compound interest update
            quantum=self.spatialMap['probabilities'][key]['regions'][region]*self.learningRate
            
        if method=='logistic':
            self.spatialMap['probabilities'][key]['visitations']+=1
            #logistic_function(base_lr, i, 1/(zones[j]**2), 10*base_lr) 
            interest = self.logistic_function(self.learningRate, 
                                              self.spatialMap['probabilities'][key]['visitations'], 
                                              1/(self.nregions**2), 
                                              self.learningRate*10)             
            quantum=self.spatialMap['probabilities'][key]['regions'][region]*interest
        
        for reg in self.spatialMap['probabilities'][key]['regions']:
            if reg==region:
                if self.spatialMap['probabilities'][key]['regions'][reg]+quantum>1:
                    self.spatialMap['probabilities'][key]['regions'][reg]=1
                else:
                    self.spatialMap['probabilities'][key]['regions'][reg]+=quantum
                    #print('\nincreasing',reg,'by',quantum, 'to', self.spatialMap['probabilities'][key]['regions'][reg])
            else:
                if self.spatialMap['probabilities'][key]['regions'][reg]-quantum/(self.nregions-1)<0:
                    self.spatialMap['probabilities'][key]['regions'][reg]=0
                else:
                    self.spatialMap['probabilities'][key]['regions'][reg]-=quantum/(self.nregions-1)
                    #print('decreasing',reg,'by',quantum/(self.nregions-1), 'to', self.spatialMap['probabilities'][key]['regions'][reg])
        

        ### dynamic zone adjustment

        if self.adjustment=='dynamic':
        
            # Adjust the home zone bbox
    
            #keydist from top = a, from bottom = keyb.ydim-a, ratio = h/a
            #
            #left, bottom, right, top
            vmove_total=abs(quantum*self.kb.ydim/self.nregions)
            hmove_total=abs(quantum*self.kb.xdim/self.nregions)
            #initial region bbox
            region_bbox = self.getRegionBbox(key_coords[0],key_coords[1])
            hz_bbox = self.spatialMap['probabilities'][key]['home_zone']['bbox']

            all_zone_left = min(hz_bbox[0], self.kb.keylist[key]['bbox']['left'])
            all_zone_right = max(hz_bbox[2], self.kb.keylist[key]['bbox']['right'])
            all_zone_bottom = min(hz_bbox[1], self.kb.keylist[key]['bbox']['bottom'])
            all_zone_top = max(hz_bbox[3], self.kb.keylist[key]['bbox']['top'])

            #ratios are key center to all_zone bound.
            
            # ((key left x - reg. left) + (key centre - key left x)) / (keyb w / nregions)
            #l = (abs(self.kb.keylist[key]['bbox']['left'] - region_bbox[0]) + self.kb.keylist[key]['center'][0]-self.kb.keylist[key]['bbox']['left'])/(region_bbox[2]-region_bbox[0])
            #l = abs(self.kb.keylist[key]['center'][0]-region_bbox[0])/(region_bbox[2]-region_bbox[0])
            l = abs(self.kb.keylist[key]['center'][0]-all_zone_left)/(all_zone_right-all_zone_left)
            hdist_reduction_left = l*hmove_total
            hdist_reduction_right = (1-l)*hmove_total
            #print(hmove_total, l, hdist_reduction_left)
            
    
            # ((key top x - reg. left) + (key top - key left x)) / (keyb w / nregions)
            #l = (abs(self.kb.keylist[key]['bbox']['bottom'] - region_bbox[1]) + self.kb.keylist[key]['center'][0]-self.kb.keylist[key]['bbox']['bottom'])/(region_bbox[3]-region_bbox[1])
            #l = abs(region_bbox[3]-self.kb.keylist[key]['center'][1])/(region_bbox[3]-region_bbox[1])
            l = abs(self.kb.keylist[key]['center'][1]-all_zone_bottom)/(all_zone_top-all_zone_bottom)
            vdist_reduction_bottom = l*vmove_total 
            vdist_reduction_top = (1-l)*vmove_total
            
            #hz_bbox[0]+=hdist_reduction_left
            #hz_bbox[2]-=hdist_reduction_right
            #hz_bbox[1]+=vdist_reduction_top
            #hz_bbox[3]-=vdist_reduction_top

            #bufferh = 0.1*(self.kb.keylist[key]['bbox']['right']-self.kb.keylist[key]['bbox']['left'])
            #bufferv = 0.1*(self.kb.keylist[key]['bbox']['top']-self.kb.keylist[key]['bbox']['bottom'])
            
            if self.kb.keylist[key]['bbox']['left'] < hz_bbox[0]:
                hz_bbox[0] = max(hz_bbox[0]-hdist_reduction_left, self.kb.keylist[key]['bbox']['left'])
            else:
                hz_bbox[0] = min(hz_bbox[0]+hdist_reduction_left, self.kb.keylist[key]['bbox']['left'])

            if self.kb.keylist[key]['bbox']['right'] < hz_bbox[2]:
                hz_bbox[2] = max(hz_bbox[2]-hdist_reduction_right, self.kb.keylist[key]['bbox']['right'])
            else:
                hz_bbox[2] = min(hz_bbox[2]+hdist_reduction_right, self.kb.keylist[key]['bbox']['right'])
        
            if self.kb.keylist[key]['bbox']['bottom'] < hz_bbox[1]:
                hz_bbox[1] = max(hz_bbox[1]-vdist_reduction_bottom, self.kb.keylist[key]['bbox']['bottom'])
            else:
                hz_bbox[1] = min(hz_bbox[1]+vdist_reduction_bottom, self.kb.keylist[key]['bbox']['bottom'])

            if self.kb.keylist[key]['bbox']['top'] < hz_bbox[3]:
                hz_bbox[3] = max(hz_bbox[3]-vdist_reduction_top, self.kb.keylist[key]['bbox']['top'])
            else:
                hz_bbox[3] = min(hz_bbox[3]+vdist_reduction_top, self.kb.keylist[key]['bbox']['top'])


        
        return
        

        #how about a frequency-recency rule?
    
    def logistic_function(self, K, x, k, x0):
        #P(t) = K / (1 + e^(-k(t-t0)))
        #P(t) is performance at time t
        #K is the upper limit (maximum performance)
        #r is the learning rate
        #t0 is the midpoint time (inflection point)
        return K / (1 + math.e**(-k * (x - x0)))
    
    def saveMemory(self,file):
        with open(file, 'w') as convert_file: 
            convert_file.write(json.dumps(self.spatialMap))
            